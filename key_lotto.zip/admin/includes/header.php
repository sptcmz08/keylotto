<?php
$adminPage = $adminPage ?? '';
$adminTitle = $adminTitle ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $adminTitle ?> - คีย์หวย Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { font-family: 'Prompt', sans-serif; }
        .sidebar-link { transition: all 0.2s ease; }
        .sidebar-link:hover { background: rgba(34, 197, 94, 0.1); transform: translateX(4px); }
        .sidebar-link.active { background: linear-gradient(135deg, #22c55e, #16a34a); color: white; box-shadow: 0 4px 15px rgba(34, 197, 94, 0.3); }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex">
    <!-- Sidebar -->
    <aside class="w-64 bg-white shadow-lg fixed h-full z-30 hidden lg:block">
        <div class="p-5 border-b bg-gradient-to-r from-green-500 to-emerald-600">
            <div class="flex items-center space-x-2">
                <i class="fas fa-clover text-white text-2xl"></i>
                <div>
                    <h1 class="text-white font-bold text-lg">คีย์หวย</h1>
                    <p class="text-white/60 text-xs">Admin Panel</p>
                </div>
            </div>
        </div>
        <nav class="p-4 space-y-1">
            <?php
            $menuItems = [
                ['href' => 'index.php', 'icon' => 'fa-gauge-high', 'label' => 'Dashboard', 'key' => 'dashboard'],
                ['href' => 'lottery_types.php', 'icon' => 'fa-dice', 'label' => 'จัดการหวย', 'key' => 'lottery'],
                ['href' => 'pay_rates.php', 'icon' => 'fa-coins', 'label' => 'อัตราจ่าย', 'key' => 'rates'],
                ['href' => 'results_manage.php', 'icon' => 'fa-trophy', 'label' => 'ผลรางวัล', 'key' => 'results'],
                ['href' => 'result_links.php', 'icon' => 'fa-link', 'label' => 'ลิงค์ดูผล', 'key' => 'links'],
                ['href' => 'bets.php', 'icon' => 'fa-receipt', 'label' => 'รายการเดิมพัน', 'key' => 'bets'],
            ];
            foreach ($menuItems as $item):
                $isActive = $adminPage === $item['key'];
            ?>
            <a href="<?= $item['href'] ?>" class="sidebar-link flex items-center space-x-3 px-4 py-2.5 rounded-xl text-sm font-medium <?= $isActive ? 'active' : 'text-gray-600' ?>">
                <i class="fas <?= $item['icon'] ?> w-5 text-center"></i>
                <span><?= $item['label'] ?></span>
            </a>
            <?php endforeach; ?>
            
            <hr class="my-3 border-gray-200">
            <a href="../index.php" class="sidebar-link flex items-center space-x-3 px-4 py-2.5 rounded-xl text-sm font-medium text-gray-600">
                <i class="fas fa-globe w-5 text-center"></i>
                <span>ดูหน้าเว็บ</span>
            </a>
            <a href="?logout=1" class="sidebar-link flex items-center space-x-3 px-4 py-2.5 rounded-xl text-sm font-medium text-red-500">
                <i class="fas fa-sign-out-alt w-5 text-center"></i>
                <span>ออกจากระบบ</span>
            </a>
        </nav>
    </aside>

    <!-- Mobile Header -->
    <div class="lg:hidden fixed top-0 left-0 right-0 bg-white shadow z-40">
        <div class="flex items-center justify-between px-4 py-3">
            <button onclick="toggleSidebar()" class="text-gray-600"><i class="fas fa-bars text-xl"></i></button>
            <span class="font-bold text-green-600"><i class="fas fa-clover mr-1"></i>Admin</span>
            <a href="?logout=1" class="text-red-500 text-sm"><i class="fas fa-sign-out-alt"></i></a>
        </div>
    </div>

    <!-- Mobile Sidebar Overlay -->
    <div id="sidebarOverlay" class="lg:hidden fixed inset-0 bg-black/50 z-40 hidden" onclick="toggleSidebar()"></div>
    <div id="mobileSidebar" class="lg:hidden fixed left-0 top-0 h-full w-64 bg-white shadow-2xl z-50 transform -translate-x-full transition-transform duration-300">
        <div class="p-5 border-b bg-gradient-to-r from-green-500 to-emerald-600 flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <i class="fas fa-clover text-white text-xl"></i>
                <span class="text-white font-bold">Admin</span>
            </div>
            <button onclick="toggleSidebar()" class="text-white"><i class="fas fa-times"></i></button>
        </div>
        <nav class="p-4 space-y-1">
            <?php foreach ($menuItems as $item):
                $isActive = $adminPage === $item['key'];
            ?>
            <a href="<?= $item['href'] ?>" class="sidebar-link flex items-center space-x-3 px-4 py-2.5 rounded-xl text-sm font-medium <?= $isActive ? 'active' : 'text-gray-600' ?>">
                <i class="fas <?= $item['icon'] ?> w-5 text-center"></i>
                <span><?= $item['label'] ?></span>
            </a>
            <?php endforeach; ?>
            <hr class="my-3"><a href="../index.php" class="sidebar-link flex items-center space-x-3 px-4 py-2.5 rounded-xl text-sm font-medium text-gray-600"><i class="fas fa-globe w-5 text-center"></i><span>ดูหน้าเว็บ</span></a>
            <a href="?logout=1" class="sidebar-link flex items-center space-x-3 px-4 py-2.5 rounded-xl text-sm font-medium text-red-500"><i class="fas fa-sign-out-alt w-5 text-center"></i><span>ออกจากระบบ</span></a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="lg:ml-64 flex-1 min-h-screen">
        <header class="bg-white shadow-sm border-b px-6 py-4 mt-14 lg:mt-0">
            <div class="flex items-center justify-between">
                <h1 class="text-xl font-bold text-gray-800"><?= $adminTitle ?></h1>
                <div class="flex items-center space-x-2 text-sm text-gray-500">
                    <i class="fas fa-user-circle text-green-500"></i>
                    <span><?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin') ?></span>
                </div>
            </div>
        </header>
        <div class="p-6">
