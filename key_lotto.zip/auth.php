<?php
// Auth guard for admin pages
require_once __DIR__ . '/config.php';

function requireLogin() {
    if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
        header('Location: login.php');
        exit;
    }
}

function getCurrentUser() {
    return $_SESSION['username'] ?? 'admin';
}

function isLoggedIn() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}
